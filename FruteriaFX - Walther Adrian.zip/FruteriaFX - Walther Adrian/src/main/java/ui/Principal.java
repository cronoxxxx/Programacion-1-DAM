package ui;

public class Principal {
    public static void main(String[] args) {
        MenuPrograma.action();
    }
}
