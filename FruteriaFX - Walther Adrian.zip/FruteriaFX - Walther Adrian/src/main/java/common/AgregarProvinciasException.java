package common;

public class AgregarProvinciasException extends Exception {
    public AgregarProvinciasException() {
        super("No te inventes provincias xd");
    }

    public AgregarProvinciasException(String message) {
        super(message);
    }
}
