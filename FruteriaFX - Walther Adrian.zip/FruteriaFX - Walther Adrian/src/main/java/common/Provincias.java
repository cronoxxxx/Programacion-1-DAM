package common;

public enum Provincias {
    Albacete, Madrid, CastillayLeon, Galicia, Cataluña, Andalucia, Canarias, Alava, Alicante, Almeria, Asturias, Avila, Badajoz, Barcelona, Burgos, Caceres, Cadiz, Cantabria, Castellon, CiudadReal, Cordoba, Cuenca, Gerona, Granada, Guadalajara, Guipuzcoa, Huelva, Huesca, IslasBaleares, Jaen, ACoruña, LaCoruña, LaRioja, Las_Palmas, Leon, Lerida, Lugo, Malaga, Murcia, Navarra, Orense, Palencia, Pontevedra, Salamanca, SantaCruzdeTenerife, Tenerife, Segovia, Sevilla, Soria, Tarragona, Teruel, Toledo, Valencia, Valladolid, Vizcaya, Zamora, Zaragoza

}


