package common;

public enum Categoria {
    football, starWars, address, pokemon, dragonBall, animal //lo que queráis series, música, juegos, personajes series, uso o no de DataFaker etc.
}
