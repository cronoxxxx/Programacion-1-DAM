package com.example.ejemploahorcado.ui;


public class Main {
    public static void main(String[] args)  {
            PruebaTotal.iniciarMenuJuego(args);
    }
}


