package org.example.common;

public enum Frutas {
    Platano,Banana,Manzana,Mandarina,Naranja,Pera
}
