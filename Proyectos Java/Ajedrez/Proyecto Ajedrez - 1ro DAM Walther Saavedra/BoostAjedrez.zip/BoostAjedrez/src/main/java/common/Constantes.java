package common;

public class Constantes {

    public static final String TURNO_DE_BLANCAS = "Turno de blancas.";
    public static final String TURNO_DE_NEGRAS = "Turno de negras.";
    public static final String INTRODUZCA_1_PARA_PROMOCIONAR_A_REINA_2_PARA_CABALLO_3_PARA_TORRE_O_4_PARA_ALFIL = "Introduzca 1 para promocionar a reina, 2 para caballo, 3 para torre o 4 para alfil.";
    public static final String INTRODUCE_UNA_OPCION_VALIDA = "Introduce una opción válida.";
    public static final String JAQUE_MATE_BLANCO = "Jaque mate blanco";
    public static final String JAQUE_MATE_NEGRO = "Jaque mate negro";
    public static final String JAQUE_BLANCO = "Jaque blanco";
    public static final String JAQUE_NEGRO = "Jaque negro";
    public static final String INTRODUZCA_LA_PIEZA_QUE_DESEA_MOVER = "Introduzca la pieza que desea mover.";
    public static final String INTRODUZCA_LA_POSICION_A_LA_QUE_DESEA_MOVER = "Introduzca la posición a la que desea mover.";
    public static final String POSICIONES_FINALES_VÁLIDAS = "Posiciones finales válidas:";
    public static final String REY_AHOGADO_TABLAS = "Rey ahogado, tablas";
}
